<?php
namespace app\Admin\model;

use think\Model;

class company extends Model
{

}