<?php
namespace app\Admin\model;

use think\Model;

class applicant extends Model
{

}
