<?php
namespace app\Admin\controller;

use app\BaseController;
use think\facade\Db;
use think\facade\View;
use think\facade\Request;
use app\admin\model\company;
use app\admin\model\applicant;

class Index extends BaseController
{
    public function index()
    {
        $company=Db::table('company')->select()->toArray();
        $position=Db::table('position')->select()->toArray();
        $applicant=Db::table('applicant')->select()->toArray();
        View::assign([
            'company'   =>  $company,
            'position'  =>  $position,
            'applicant' =>  $applicant
        ]);
        return View::fetch('index/index');
    }

    public function cagree()
    {
        $res=Db::table('company')->where('id', Request::param('id'))->update(['state'=>1]);
        echo"<script>alert('认证成功')</script>";
        return $this->index();
    }

    public function cdelete()
    {
        // Db::table('company')->where('id', Request::param('id'))->delete();
        echo"<script>alert('以防误删，暂时注销功能，取消注销后即可打开！')</script>";
        return $this->index();
    }

    public function pagree()
    {
        $res=Db::table('position')->where('id', Request::param('id'))->update(['state'=>1]);
        echo"<script>alert('认证成功')</script>";
        return $this->index();
    }

    public function pdelete()
    {
        Db::table('position')->where('id', Request::param('id'))->delete();
        //echo"<script>alert('以防误删，暂时注销功能，取消注销后即可打开！')</script>";
        echo"<script>alert('删除成功')</script>";
        return $this->index();
    }
    public function aagree()
    {
        $res=Db::table('applicant')->where('id', Request::param('id'))->update(['state'=>1]);
        echo"<script>alert('认证成功')</script>";
        return $this->index();
    }

    public function adelete()
    {
        // Db::table('applicant')->where('id', Request::param('id'))->delete();
        echo"<script>alert('以防误删，暂时注销功能，取消注销后即可打开！')</script>";
        return $this->index();
    }

    public function hello($name = 'ThinkPHP6')
    {
        return 'hello,' . $name;
    }
    
    public function GetModel()//查询函数
    {
        $test1 = Db::name('company')->where('id', 1)->find();
        $test2 = Db::name('applicant')->where('id', 1)->find();
        foreach($test1 as $row)
        {
            echo "This is:".$row."<br>";
        }
    }

    public function Insert()//新增函数
    {
        $newdata=[
            'trade'         =>'金融',
            'name'          =>'金融天地',
            'adress'        =>'浙江省杭州市萧山路11号',
            'legal_person'  =>'王今江',
            'reg_capital'   =>'100,100,000',
            'info'          =>'我们公司的主要业务是帮助投资理财，公司规模较大，拥有1000名员工，并在2018年于纽约上市。',
            'contact'       =>'9934-8879'
        ];
        $res=Db::name('company')->insert($newdata);
        return $res;
    }
}
