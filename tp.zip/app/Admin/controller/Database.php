<?php
namespace app\Admin\controller;

use think\facade\Db;

class Database
{
    public function Index()
    {
        $user = Db::connect('recruit')->table('company')->select();
        return $user;
    }
}
