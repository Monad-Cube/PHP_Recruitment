<?php
namespace app\applicant\controller;

use app\BaseController;

use app\applicant\controller\Redirect;

use think\facade\View;

class Index extends BaseController
{
    //返回
    public function Index()
    {
        $Login=new Redirect($this->app);
        return $Login->toLogin();
    }
/*     //Test
    public function Index()
    {
        return View::fetch('Test/test');
    } 
 */
    
}