<?php
namespace app\applicant\controller;

use app\BaseController;
use think\facade\Request;
use think\facade\Session;
use think\facade\View;
use think\facade\Db;
use app\Applicant\controller\Collect;


class Redirect extends BaseController
{
    public function __construct()
    {
        View::assign('user',Session::get('user_info'));
    }
    public function test()
    {
        return redirect('http://www.app.com/index/test');
    }
    //去主页模板
    public function Home()
    {
        $user=Session::get('user_info');
        View::assign('user',$user);
        if(Session::get('user_info')['property']=='company')
        {
            $company=Db::table('company')->where('email',$user['email'])->find();
            View::assign([
                'company'   =>  $company
            ]);
            if($company['state']==1)
            {
                $company['state']="未认证";
            }
            else
            {
                $company['state']="已认证";
            }
            return View::fetch('Home/company_index');
        }
        else
        {
            $hot=Db::table('position')->where('popularity','>',20)->select()->toArray();
            $date=date('Y.m');
            $new=Db::table('position')->where('post_time','like',"$date%")->select()->toArray();
            //dump($new);
            View::assign([
                'hot'   =>  $hot,
                'new'   =>  $new
            ]);
            return View::fetch('Home/applicant_index');
        }
    }
    //主页
    public function toHome()
    {
        return redirect('http://www.app.com/home/index');
    }
    //去登录模板
    public function toLogin()
    {
        return View::fetch('Log/login');
    }
    //登录
    public function Login()
    {
        return redirect('http://www.app.com/log/login');
    }
    //登出
    public function Logout()
    {
        return View::fetch('Log/logout');
    }
    //注册
    public function Register()
    {
        $judge=Request::param('type');
        if($judge==0)
        {
            $inputtype='applicant';
        }
        else
        {
            $inputtype='company';
        }
        $userinfo=['property' => $inputtype,
            'email' => Request::param('email'),
            'password' => Request::param('password')];
        dump($userinfo);
        return redirect('http://www.app.com/log/register')->with('register_info', $userinfo);
    }
    //去注册模板
    public function toRegister()
    {
        return View::fetch('Register/register');
    }
    //查找
    public function search()
    {
        return View::fetch('Function/position');
    }


    //简历
    public function List()
    {
        return View::fetch('Function/list');
    }

    //发送
    public function CompanyList()
    {
        return View::fetch('Function/companylist');
    }
    
    //发送
    public function Delivery()
    {
        
        return redirect("http://www.app.com/Collect/check");
    }

    //发布职位
    public function Create()
    {
        return View::fetch('Function/create');
    }
    
    //发布职位查看
    public function Position()
    {
        echo"successs!!";
        View::assign(['position' => $position]);
        return View::fetch('Function/positions');
    }

    //简历
    public function Resume()
    {
        return View::fetch('Function/resume');
    }
    //处理简历
    //简历
    public function HandleResumes()
    {
        return View::fetch('Function/HandleResumes');
    }

    
    //收藏
    public function CollectPosition()
    {
        $user=Session::get('user_info');
        $app=Db::table('applicant')->where('email',$user['email'])->find();
        $position=Db::table('position')->where('id',$app['collection_position_id'])->find();
        //dump($position);
        View::assign([
            'app'   =>  $app['collection_position_id'],
            'position'  =>  $position
        ]);
        return View::fetch('Function/collections_position');
    }

    public function unCollectPosition()
    {
        $user=Session::get('user_info');
        $app=Db::table('applicant')->where('email',$user['email'])->find();
        $app['collection_position_id']=0;
        Db::table('applicant')->where('id',$app['id'])->update($app);
        View::assign([
            'app'   =>  0
        ]);
        return View::fetch('Function/collections_position');
    }

    //收藏
    public function CollectCompany()
    {
        $user=Session::get('user_info');
        $app=Db::table('applicant')->where('email',$user['email'])->find();
        $company=Db::table('company')->where('id',$app['collection_company_id'])->find();
        //dump($company);
        View::assign([
            'app'   =>  $app['collection_company_id'],
            'company'   =>  $company
        ]);
        return View::fetch('Function/collections_company');
    }

    public function unCollectCompany()
    {
        $user=Session::get('user_info');
        $app=Db::table('applicant')->where('email',$user['email'])->find();
        $app['collection_company_id']=0;
        Db::table('applicant')->where('id',$app['id'])->update($app);
        View::assign([
            'app'   =>  0,
        ]);
        return View::fetch('Function/collections_company');
    }

}