<?php
    namespace app\applicant\controller;
    
	use app\BaseController;
    
	use think\Session;
    use think\facade\View;
    
	class Check extends BaseController
	{
		/**
		 * 初始化方法
		 */
	    public function CheckLogin()
	    {
	    	// 检测用户session是否存在
		    if (!Session::get('admin_login')) {
		    	$this->error("请先登录!", 'public/login.html');
            }
            else
            {
                return redirect();
            }
        }
        

	}
