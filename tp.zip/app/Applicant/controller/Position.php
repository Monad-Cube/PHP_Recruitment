<?php
namespace app\applicant\controller;

use app\BaseController;
use think\facade\Request;
use think\facade\Session;
use think\facade\View;
use think\facade\Db;
use app\Applicant\controller\Collect;

class Position Extends BaseController
{
    public function __construct()
    {
        View::assign('user',Session::get('user_info'));
    }

    public function home()
    {
        return redirect("http://www.app.com/redirect/home"); 
    }

    public function post()
    {
        $user=Session::get('user_info');
        $post=[
            'name'          =>  Request::param('name'),
            'company'       =>  Request::param('company'),
            'type'          =>  Request::param('type'),
            'place'         =>  Request::param('place'),
            'number'        =>  Request::param('number'),
            'requirement'   =>  Request::param('requirement'),
            'treatment'     =>  Request::param('treatment'),
            'allowance'     =>  Request::param('allowance'),
            'contact'       =>  Request::param('contact'),
            'post_time'     =>  date('Y.m.d'),
            'popularity'    =>  0
        ];
        $res=Db::table('position')->insert($post);
        return redirect("http://www.app.com/redirect/home"); 
    }

    public function check()
    {
        $user=Session::get('user_info');
        $company=Db::table('company')->where('email',$user['email'])->find();
        //dump($company);
        $position=Db::table('position')->where('company',$company['name'])->select()->toArray();
        //dump($position);
        View::assign(['position'    =>  $position]);
        return View::fetch('Function/positions');
    }

    public function create()
    {
        return redirect("http://www.app.com/redirect/create"); 
    }
    
    public function HandleResumes()
    {
        $user=Session::get('user_info');
        $company=Db::table('company')->where('email',$user['email'])->find();
        //dump($company);
        $position=Db::table('position')->where('company',$company['name'])->select()->toArray();
        //dump($position);
        $key=0;
        $applicant=array();
        foreach($position as $pos)
        {
            //dump($pos['id']);
            $pos_mem[$key]=Db::table('resume')->where('position_id',$pos['id'])->find();
            if($pos_mem[$key] && $pos_mem[$key]['state']==1)
            {
                //dump($pos_mem);
                $applicant[$key]=Db::table('applicant')->where('id',$pos_mem[$key]['applicant_id'])->find();
                //dump($applicant[$key]);
                $key++;
            }
        }
        //dump($pos_mem);
        //dump($applicant);
        View::assign([
            'resume'    =>  $pos_mem[0],
            'position'  =>  $position[0],
            'applicant' =>  $applicant
        ]);
        return View::fetch('Function/HandleResumes'); 
    }

    public function agree()
    {
        $user=Session::get('user_info');
        $id=Request::param('id');
        $resume=Db::table('resume')->where('applicant_id',$id)->find();
        $resume['state']=2;
        Db::table('resume')->where('id',$resume['id'])->update($resume);
        return $this->HandleResumes();
    }

    public function reject()
    {
        $user=Session::get('user_info');
        $id=Request::param('id');
        $resume=Db::table('resume')->where('applicant_id',$id)->find();
        $resume['state']=3;
        Db::table('resume')->where('id',$resume['id'])->update($resume);
        return $this->HandleResumes();
    }

    public function delete()
    {
        $user=Session::get('user_info');
        $id=Request::param('id');
        Db::table('position')->where('id',$id)->delete();
        return $this->check(); 
    }
    
    public function authorize()
    {
        $user=Session::get('user_info');
        $id=Request::param('id');
        $resume=Db::table('resume')->where('applicant_id',$id)->find();
        $resume['state']=3;
        return "<script>success</script>";
    }

}