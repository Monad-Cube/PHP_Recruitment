<?php
namespace app\applicant\controller;

use app\BaseController;
use think\facade\Request;
use think\facade\Session;
use think\facade\View;
use think\facade\Db;
use think\facade\Filesystem;


class Test extends BaseController
{
    public function Index(Request $request)
    {
        $file = request() -> file('file');

        if ($file == null) {
            echo '未上传图片';
        }
    
        $temp = explode(".", $_FILES["file"]["name"]);
        $extension = end($temp);
    
        if(!in_array($extension, array("jpeg","jpg","png"))){
            echo"上传图片不合法";
        }
        $saveName = Filesystem::disk('photo') -> putFile('photo', $file, 'md5');
    
        exit(str_replace('\\', '', '/upload/' . $saveName));

    }
 
}
