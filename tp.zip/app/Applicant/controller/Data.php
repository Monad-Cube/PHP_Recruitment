<?php
namespace app\applicant\controller;

use app\BaseController;

use think\facade\View;

class Data extends BaseController
{
    //返回
    public function toWhere()
    {
        echo"to where!!";
        View::assign([
            'name'      =>  '100',
            'email'     =>  'luooxi@hdu.edu.cn'
        ]); 
        return 0;
    }

    
}