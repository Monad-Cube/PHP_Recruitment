<?php
namespace app\applicant\controller;

use app\BaseController;
use think\facade\Request;
use think\facade\Session;
use think\facade\View;
use think\facade\Db;


class Collect extends BaseController
{
    
    
    public function __construct()
    {

    }

    
    
    public function check ()
    {
        $user=Session::get('user_info');
        //dump($user);
        $app=Db::table('applicant')->where('email', $user['email'])->find();
        //dump($app);
        $resume=Db::table('resume')->where('applicant_id', $app['id'])->find();
        //dump($resume);
        $position=Db::table('position')->where('id', $resume['position_id'])->find();
        //投递状态
        if($resume['state']==1)
        {
            $position['state']="已提交";
        }
        else if($resume['state']==2)
        {
            $position['state']="公司已接受，等待面试";
        }
        else if($resume['state']==3)
        {
            $position['state']="公司已拒绝";
        }
        
        //dump($position);
        View::assign([
            'user'      =>  $user,
            'position'    =>  $position,
            ]);
        return View::fetch('function/delivery');
    }


    public function collect ()
    {

    }
}