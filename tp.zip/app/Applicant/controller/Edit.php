<?php
namespace app\applicant\controller;

use app\BaseController;
use think\facade\Request;
use think\facade\Session;
use think\facade\View;
use think\facade\Db;
use app\Applicant\controller\Collect;

class Edit Extends BaseController
{
    public function __construct()
    {
        View::assign('user',Session::get('user_info'));
    }

    public function name()
    {
        $name=Request::param('name');

        $user=Session::get('user_info');
        $company=Db::table('company')->where('email',$user['email'])->find();

        $company['name']=$name;
        $res=Db::table('company')->where('id',$company['id'])->update($company);
        return redirect("http://www.app.com/redirect/home");
    }

    public function info()
    {
        $info=Request::param('info');

        $user=Session::get('user_info');
        $company=Db::table('company')->where('email',$user['email'])->find();

        $company['info']=$info;
        $res=Db::table('company')->where('id',$company['id'])->update($company);
        return redirect("http://www.app.com/redirect/home");
    }

    public function city()
    {
        $city=Request::param('city');

        $user=Session::get('user_info');
        $company=Db::table('company')->where('email',$user['email'])->find();

        $company['address']=$city;
        $res=Db::table('company')->where('id',$company['id'])->update($company);
        return redirect("http://www.app.com/redirect/home");
    }
}