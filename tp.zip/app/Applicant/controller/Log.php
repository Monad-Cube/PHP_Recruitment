<?php
namespace app\applicant\controller;

use app\BaseController;

use app\applicant\controller\Check;

use think\facade\Request;
use think\facade\Session;
use think\facade\View;
use think\facade\Db;

class Log extends BaseController
{
    //登录检查
    public function Login()
    {
        $inputname=Request::param('email'); //获取Form数据

        $inputpwd=Request::param('password');
        $userinfo=Db::table('user')->where('email', $inputname)->find(); //使用数组作为查询条件
        
        if(!$userinfo)   
        {
            echo "<script>alert('登陆失败，不存在此用户名')</script>";
            return redirect('http://www.app.com/Redirect/Login');
        }   
        else{        
    
            if($inputpwd!=$userinfo['password'])            
        
            echo "登陆失败，密码错误！".$userinfo['password'];        
        
            else
            {        
                Session::set('user_info', $userinfo);
                return redirect('http://www.app.com/Redirect/home');
        
                
            }
    
        } 

        
    }

    //注册
    public function Register()
    {
/*         $judge=Request::param('type');
        if($judge==0)
        {
            $inputtype='applicant';
        }
        else
        {
            $inputtype='company';
        }
        $email=Request::param('email');
        $password=Request::param('password');
        echo'password:'.Request::param('test');
        $userinfo=['property' => $inputtype,
            'email' => $email,
            'password' => $password]; */
        $userinfo=Session('register_info');
        

        Db::table('user')->insert($userinfo);
        Session::set('user_info', $userinfo);

        return redirect('http://www.app.com/Redirect/home');
    }

    public function goHome()
    {

    }
}