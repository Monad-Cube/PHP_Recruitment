<?php
namespace app\applicant\controller;

use app\BaseController;
use think\facade\Request;
use think\facade\Session;
use think\facade\Db;
use think\facade\View;


class Search extends BaseController
{
    public function __construct()
    {
        $user_info=Session::get('user_info');
        View::assign('user',$user_info);
    }

    public function search()
    {
        //echo"Search successfully <br>".Request::param("selection")."<br>";
        $res=Request::param("selection");
        $content=Request::param("search_content");
        //$email=Session::get("email");
        

        if($res == "position")
        {
            $position = Db::table('position')->where('name', $content)->select()->toArray();
            //热度算法
            foreach($position as $key )
            {
                $key['popularity']+=1;
                Db::table('position')->where('id', $key['id'])->update(['popularity'  =>  $key['popularity']]);
            }
            
            //View::assign('info', $userinfo);
            return View::fetch('function/list_position',[
                'info'      =>  $position,
                'search'    =>  $content,
                ]);
        }
        else if($res == "company")
        {
            $company = Db::table('company')->where('name', $content)->find();
            //dump($company);e
            //View::assign('info', $userinfo);
            return View::fetch('function/list_company',[
                'info'      =>  $company,
                'search'    =>  $content,
                ]);
        }

        
    }
    public function apply()
    {
        $pos_id=Request::param("position_id")-'0';
        //$email=Session::get("email");
        $user_info=Session::get('user_info');
        //dump($user_info);
        //dump($user_info['email']);
        $applicant_info=Db::table('applicant')->where('email', $user_info['email'])->find();
        //dump($applicant_info['id']);
        //dump($pos_id);
        $date=[
            "position_id"   =>  $pos_id,
            "applicant_id"  =>  $applicant_info['id'],
            "state"         =>  1
        ];
        $res=Db::table('resume')->insert($date);
        //dump($res);
         
        return $this->home();
    }


    public function collect()
    {
        $select=Request::param('selection');
        if($select=='position')
        {
            $id=Request::param('position_id')-'0';
            $user=Session::get('user_info');
            dump($id);
            //dump($user_info['email']);
            $applicant_info=Db::table('applicant')->where('email', $user['email'])->find();
            dump($applicant_info);
            //dump($pos_id);
            $applicant_info['collection_position_id']=$id;
            $res=Db::table('applicant')->where('email',$user['email'])->update($applicant_info);
            //dump($res);
        }
        else
        {
            $id=Request::param('company_id')-'0';
            //$email=Session::get("email");
            $user=Session::get('user_info');
            //dump($user_info);
            //dump($user_info['email']);
            $applicant_info=Db::table('applicant')->where('email', $user['email'])->find();
            //dump($applicant_info['id']);
            //dump($pos_id);
            $applicant_info['collection_company_id']=$id;
            $res=Db::table('applicant')->where('email',$user['email'])->update($applicant_info);
            //dump($res);
        }

         
        return $this->home();
    }

    public function home()
    {
        return redirect('/Redirect/home');
    }

}