<?php
// 应用公共文件

    error_reporting(E_ERROR | E_WARNING | E_PARSE);
