<?php /*a:1:{s:61:"D:\WampServer\www\ThinkPHP\tp\app\admin\view\index\index.html";i:1592623494;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            text-align: center;
        }
        
        h2 {
            color: mediumturquoise;
        }
        
        .company,
        .position,
        .applicant {
            width: 100%;
            text-align: center;
        }
        
        .c_table,
        .p_table,
        .a_table {
            margin: auto;
            border-collapse: collapse;
            border-color: mistyrose;
            text-align: center;
        }
        
        th {
            border-style: initial;
        }
        
        td {
            border-radius: 10px;
            border: solid 2px chocolate;
            width: 100px;
            height: 50px;
            text-align: center;
        }
        
        .info {
            margin-left: 15px;
            width: 200px;
            text-overflow: ellipsis;
            overflow: hidden;
            white-space: nowrap;
        }
        
        .form {
            border-radius: 10px;
            margin: 5px;
            display: inline-block;
        }
        
        button {
            width: 130px;
            border-radius: 10px;
        }
        
        .agree {
            background-color: #4CAF50;
            /* Green */
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
        }
        
        .delete {
            background-color: darkorange;
            /* Green */
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
        }
    </style>
    <title>后台管理</title>
</head>

<body>
    <div class="company">
        <h2>公司管理</h2>
        <div>
            <table class="c_table">

                <tr style="font-weight: bold;">
                    <td>行业</td>
                    <td>地址</td>
                    <td>公司法人</td>
                    <td>注册资金</td>
                    <td>公司简历</td>
                    <td>联系方式</td>
                    <td style="width: 300px;">操作</td>
                </tr>
                <?php if(is_array($company) || $company instanceof \think\Collection || $company instanceof \think\Paginator): $i = 0; $__LIST__ = $company;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$comp): $mod = ($i % 2 );++$i;?>
                <tr>
                    <td><?php echo htmlentities($comp['trade']); ?></td>
                    <td><?php echo htmlentities($comp['address']); ?></td>
                    <td><?php echo htmlentities($comp['legal_person']); ?></td>
                    <td><?php echo htmlentities($comp['reg_capital']); ?></td>
                    <td>
                        <div class="info"><?php echo htmlentities($comp['info']); ?></div>
                    </td>
                    <td><?php echo htmlentities($comp['contact']); ?></td>
                    <td>
                        <div class="form">
                            <form action="<?php echo url('http://index/cagree'); ?>" method="POST">
                                <?php if($comp['state']==1): ?>
                                <button class="agree" type="button" style="background-color: mediumslateblue;">已认证
                                <?php else: ?>
                                <button class="agree" type="submit">同意认证
                                <input type="hidden" name="id" value="<?php echo htmlentities($comp['id']); ?>">
                                <?php endif; ?>
                            </form>
                        </div>
                        <div class="form" >
                            <form action="<?php echo url('http://index/cdelete'); ?>" method="POST">
                                <button class="delete" type="subimt">删除企业
                                <input type="hidden" name="id" value="<?php echo htmlentities($comp['id']); ?>">
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </table>
        </div>
    </div>
    <div class="position">
        <h2>职位管理</h2>
        <div>
            <table class="p_table">
                <tr style="font-weight: bold;">
                    <td>名称</td>
                    <td>类型</td>
                    <td>公司</td>
                    <td style="width: 300px;">操作</td>
                </tr>
                <?php if(is_array($position) || $position instanceof \think\Collection || $position instanceof \think\Paginator): $i = 0; $__LIST__ = $position;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$pos): $mod = ($i % 2 );++$i;?>
                <tr>
                    <td><?php echo htmlentities($pos['name']); ?></td>
                    <td><?php echo htmlentities($pos['type']); ?></td>
                    <td><?php echo htmlentities($pos['company']); ?></td>
                    <td>                       
                        <div class="form">
                            <form action="<?php echo url('http://index/pagree'); ?>" method="POST">
                                <?php if($pos['state']==1): ?>
                                <button class="agree" type="button" style="background-color: mediumslateblue;">已认证
                                <?php else: ?>
                                <button class="agree" type="submit">同意认证
                                <input type="hidden" name="id" value="<?php echo htmlentities($pos['id']); ?>">
                                <?php endif; ?>
                            </form>
                        </div>
                        <div class="form" >
                            <form action="<?php echo url('http://index/pdelete'); ?>" method="POST">
                                <button class="delete" type="subimt">删除职位
                                <input type="hidden" name="id" value="<?php echo htmlentities($pos['id']); ?>">
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </table>
        </div>
    </div>
    <div class="applicant">
        <h2>用户管理</h2>
        <div>
            <table class="a_table">
                <tr style="font-weight: bold;">
                    <td>姓名</td>
                    <td>工作类型</td>
                    <td>地址</td>
                    <td>教育背景</td>
                    <td style="width: 300px;">操作</td>
                </tr>
                <?php if(is_array($applicant) || $applicant instanceof \think\Collection || $applicant instanceof \think\Paginator): $i = 0; $__LIST__ = $applicant;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$app): $mod = ($i % 2 );++$i;?>
                <tr>
                    <td><?php echo htmlentities($app['name']); ?></td>
                    <td><?php echo htmlentities($app['job_type']); ?></td>
                    <td><?php echo htmlentities($app['address']); ?></td>
                    <td><?php echo htmlentities($app['education']); ?></td>
                    <td>                       
                        <div class="form">
                            <form action="<?php echo url('http://index/aagree'); ?>" method="POST">
                                <?php if($app['state']==1): ?>
                                <button class="agree" type="button" style="background-color: mediumslateblue;">已认证
                                <?php else: ?>
                                <button class="agree" type="submit">同意认证
                                <input type="hidden" name="id" value="<?php echo htmlentities($app['id']); ?>">
                                <?php endif; ?>
                            </form>
                        </div>
                        <div class="form" >
                            <form action="<?php echo url('http://index/adelete'); ?>" method="POST">
                                <button class="delete" type="subimt">拒绝申请
                                <input type="hidden" name="id" value="<?php echo htmlentities($app['id']); ?>">
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </table>
        </div>
    </div>


</body>

</html>