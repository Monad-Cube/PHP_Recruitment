<?php /*a:1:{s:72:"D:\WampServer\www\ThinkPHP\tp\app\applicant\view\Home\company_index.html";i:1592569025;}*/ ?>
﻿<!DOCTYPE HTML>
<html xmlns:wb="http://open.weibo.com/wb">

<head>
    </script>
    <script type="text/javascript" async="" src="/static/js/conversion.js"></script>
    <script src="/static/js/allmobilize.min.js" charset="utf-8" id="allmobilize"></script>
    <style type="text/css"></style>
    <meta content="no-siteapp" http-equiv="Cache-Control">
    <link media="handheld" rel="alternate">
    <!-- end 云适配 -->
    <meta content="text/html; charset=utf-8" http-equiv="Content-Type">
    <title><?php echo htmlentities($company['name']); ?>-拉勾网-最专业的互联网招聘平台</title>
    <meta content="23635710066417756375" property="qc:admins">
    <meta name="description" content="平潭协创进出口贸易有限公司 福建平潭协创进出口贸易有限公司 上海 移动互联网 天使轮 150-500人 测试的发打发打发大范德萨发">
    <meta name="keywords" content="平潭协创进出口贸易有限公司 福建平潭协创进出口贸易有限公司 上海 移动互联网 天使轮 150-500人 测试的发打发打发大范德萨发">
    <meta content="QIQ6KC1oZ6" name="baidu-site-verification">

    <!-- <div class="web_root"  style="display:none">http://www.lagou.com</div> -->
    <script type="text/javascript">
        var ctx = "http://www.lagou.com";
        console.log(1);
    </script>
    <link href="http://www.lagou.com/images/favicon.ico" rel="Shortcut Icon">
    <link href="/static/css/style.css" type="text/css" rel="stylesheet">
    <link href="/static/css/external.min.css" type="text/css" rel="stylesheet">
    <link href="/static/css/popup.css" type="text/css" rel="stylesheet">
    <script type="text/javascript" src="/static/js/jquery.1.10.1.min.js"></script>
    <script src="/static/js/jquery.lib.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="/static/js/ajaxfileupload.js"></script>
    <script src="/static/js/additional-methods.js" type="text/javascript"></script>
    <!--[if lte IE 8]>
    <script type="text/javascript" src="/static/js/excanvas.js"></script>
<![endif]-->
    <script type="text/javascript">
        var youdao_conv_id = 271546;
    </script>
    <script src="/static/js/conv.js" type="text/javascript"></script>
    <script src="/static/js/ajaxCross.json" charset="UTF-8"></script>
</head>

<body>
    <div id="body">
        <div id="header">
            <div class="wrapper">
                <a class="logo" href="home">
                    <img width="229" height="43" alt="拉勾招聘-专注互联网招聘" src="/static/images/logo.png">
                </a>
                <ul id="navheader" class="reset">
                    <li class="current"><a href="home">公司</a></li>
                    <li><a rel="nofollow" href="create">发布职位</a></li>
                </ul>
                <dl class="collapsible_menu">
                    <dt>
           			<span><?php echo htmlentities($user['email']); ?></span> 
            		<span class="red dn" id="noticeDot-1"></span>
            		<i></i>
            	</dt>
                    </dt>
                    <dd style="display: none;"><a href="positions">我发布的职位</a></dd>
                    <dd style="display: none;"><a href="positions">我收到的简历</a></dd>
                    <dd class="btm" style="display: none;"><a href="myhome.html">我的公司主页</a></dd>
                    <dd style="display: none;"><a href="accountBind.html">帐号设置</a></dd>
                    <dd class="logout" style="display: none;"><a rel="nofollow" href="logout.html">退出</a></dd>
                </dl>
                </dl>
            </div>
        </div>
        <!-- end #header -->
        <div id="container">
            <!-- <script src="/static/js/swfobject_modified.js" type="text/javascript"></script> -->
            <div class="clearfix">

                <div class="content_l">
                    <div class="c_detail" style="height: 200px;margin-top: 100px;">
                        <!-- <div style="background-color:#fff;width: 196px;" class="c_logo">
                                                       <a title="上传公司LOGO" id="logoShow" class="inline cboxElement" href="#logoUploader">
                                <img width="190" height="190" alt="公司logo" src="/static/images/logo_default.png">

                            <span>更换公司图片<br>190px*190px 小于5M</span>
                            </a> 
                        </div>-->

                        <!--  			                <div class="c_logo" style="background-color:#fff;">
			                	<div id="logoShow">
			                		<img src="style/images/logo_default.png" width="190" height="190" alt="公司logo" />
		                        	<span>更换公司图片<br />190px*190px 小于5M</span>
		                        </div>
		                        <input onchange="img_check(this,'http://www.lagou.com/cd/saveProfileLogo.json',25927,'logo');" type="file" id="logo" name="logo" title="支持jpg、jpeg、gif、png格式，文件小于5M" />
			                     
			                </div>
		                    <span class="error" id="logo_error" style="display:none;"></span>
						     -->

                        <div class="c_box companyName" style="margin-left: 0px;">
                            <h2 style="" title="">公司名称： <?php echo htmlentities($company['name']); ?></h2>

                            <em class="unvalid"></em>
                            <span class="va dn">

                            </span> <?php if($company['state']=="未认证"): ?><a style="margin-top: 50px;" target="_blank" class="applyC" href="http://position/authorize">申请认证</a> <?php else: ?> <span class="va dn"><?php echo htmlentities($company['state']); ?></span><?php endif; ?>
                            <div class="clear"></div>
                            <form class="clear editDetail dn" id="editDetailForm" action="<?php echo url('http://Edit/name'); ?>" method="POST">
                                <input type="text" placeholder="请输入公司名称" maxlength="15" value="" name="name" id="companyShortName">
                                <br>
                                <input type="hidden" value="25927" id="companyId" name="companyId">
                                <input type="submit" value="保存" id="saveDetail" class="btn_small">
                                <a id="cancelDetail" class="btn_cancel_s">取消</a>
                            </form>
                        </div>
                        <a title="编辑基本信息" class="c_edit" id="editCompanyDetail" href="javascript:void(0);"></a>
                        <div class="clear"></div>
                    </div>

                    <div class="c_breakline"></div>

                    <!-- end #Product -->

                    <div id="Profile">
                        <div class="profile_wrap">
                            <!--无介绍 -->
                            <dl class="c_section dn">
                                <dt>
					                <h2><em></em>公司介绍</h2>
					                </dt>
                                <dd>
                                    <div class="addnew">
                                        详细公司的发展历程、让求职者更加了解你!<br>
                                        <a id="addIntro" href="javascript:void(0)">+添加公司介绍</a>
                                    </div>
                                </dd>
                            </dl>
                            <!--编辑介绍-->
                            <dl class="c_section newIntro dn">
                                <dt>
					                        <h2><em></em>公司介绍</h2>
					                    </dt>
                                <dd>
                                    <form id="companyDesForm" action="<?php echo url('http://Edit/info'); ?>" method="POST">
                                        <textarea placeholder="请分段详细描述公司简介、企业文化等" name="companyProfile" id="companyProfile">该方法嘎嘎该方法嘎嘎该方法嘎嘎该方法嘎嘎该方法嘎嘎该方法嘎嘎该方法嘎嘎该方法嘎嘎该方法嘎嘎该方法嘎嘎该方法嘎嘎该方法嘎嘎</textarea>
                                        <div class="word_count fr">你还可以输入 <span>1000</span> 字</div>
                                        <div class="clear"></div>
                                        <input type="submit" value="保存" id="submitProfile" class="btn_small">
                                        <a id="delProfile" class="btn_cancel_s" href="javascript:void(0)">取消</a>
                                    </form>
                                </dd>
                            </dl>

                            <!--有介绍-->
                            <dl class="c_section">
                                <dt>
					                   		<h2><em></em>公司介绍</h2>
					                   	</dt>
                                <dd>
                                    <div class="c_intro"><?php echo htmlentities($company['info']); ?></div>
                                    <a title="编辑公司介绍" id="editIntro" class="c_edit" href="javascript:void(0)"></a>
                                </dd>
                            </dl>
                        </div>

                    </div>
                    <!-- end #Profile -->

                    <!--[if IE 7]> <br /> <![endif]-->

                    <!--无招聘职位-->
                    <dl id="noJobs" class="c_section">
                        <dt>
		                    	<h2><em></em>招聘职位</h2>
		                    </dt>
                        <dd>
                            <div class="addnew">
                                发布需要的人才信息，让伯乐和千里马尽快相遇……<br>
                                <a href="create">+添加招聘职位</a>
                            </div>
                        </dd>
                    </dl>

                    <input type="hidden" value="" name="hasNextPage" id="hasNextPage">
                    <input type="hidden" value="" name="pageNo" id="pageNo">
                    <input type="hidden" value="" name="pageSize" id="pageSize">
                    <div id="flag"></div>
                </div>
                <!-- end .content_l -->

                <div class="content_r">
                    <div id="Tags">
                        <div id="c_tags_show" class="c_tags solveWrap">
                            <table>
                                <tbody>
                                    <tr>
                                        <td width="45">地点</td>
                                        <td><?php echo htmlentities($company['address']); ?></td>
                                    </tr>
                                    <tr>
                                        <td>领域</td>
                                        <!-- 支持多选 -->
                                        <td title=""><?php echo htmlentities($company['trade']); ?></td>
                                    </tr>
                                    <tr>
                                        <td>主页</td>
                                        <td>
                                            <a rel="nofollow" title="http://www.weimob.com" target="_blank" href="http://www.weimob.com">http://www.weim...</a>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <a id="editTags" class="c_edit" href="javascript:void(0)"></a>
                        </div>
                        <div id="c_tags_edit" class="c_tags editTags dn">
                            <form id="tagForms">
                                <table>
                                    <tbody>
                                        <tr>
                                            <td>地点</td>
                                            <td>
                                                <input type="text" placeholder="请输入地点" value="上海" name="city" id="city">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>领域</td>
                                            <!-- 支持多选 -->
                                            <td>
                                                <input type="hidden" value="移动互联网" id="industryField" name="industryField">
                                                <input type="button" style="background:none;cursor:default;border:none !important;" disable="disable" value="移动互联网" id="select_ind" class="select_tags">
                                                <!-- <div id="box_ind" class="selectBox dn">
		                                    <ul class="reset">
			                                    				                        							                            			<li class="current">移动互联网</li>
				                            							                            		                                    </ul>
		                                </div>	 -->
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>规模</td>
                                            <td>
                                                <input type="hidden" value="150-500人" id="companySize" name="companySize">
                                                <input type="button" value="150-500人" id="select_sca" class="select_tags">
                                                <div class="selectBox dn" id="box_sca" style="display: none;">
                                                    <ul class="reset">
                                                        <li>少于15人</li>
                                                        <li>15-50人</li>
                                                        <li>50-150人</li>
                                                        <li class="current">150-500人</li>
                                                        <li>500-2000人</li>
                                                        <li>2000人以上</li>
                                                    </ul>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>主页</td>
                                            <td>
                                                <input type="text" placeholder="请输入网址" value="http://www.weimob.com" name="companyUrl" id="companyUrl">
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <input type="hidden" id="comCity" value="上海">
                                <input type="hidden" id="comInd" value="移动互联网">
                                <input type="hidden" id="comSize" value="150-500人">
                                <input type="hidden" id="comUrl" value="http://www.zmtpost.com">
                                <input type="submit" value="保存" id="submitFeatures" class="btn_small">
                                <a id="cancelFeatures" class="btn_cancel_s" href="javascript:void(0)">取消</a>
                                <div class="clear"></div>
                            </form>
                        </div>
                    </div>
                    <!-- end #Tags -->

                    <dl class="c_section c_stages">
                        <dt>
                    	<h2><em></em>创立资金</h2>
                        <a title="编辑融资阶段" class="c_edit" href="javascript:void(0)"></a>
                        <br>
                        <div style="font-size: 25px;margin-left: 75px;">
                            <?php echo htmlentities($company['reg_capital']); ?>
                            <a target="_blank" class="weibo" href="http://weimob.weibo.com"></a>
                        </div>
                        </dt>
                        <dd>
                            <form class="dn" id="stageform">
                                <div class="stageSelect">
                                    <form action="">
                                        <span>注册资金</span>
                                        <input type="hidden" value="" id="financeStage" name="financeStage">
                                        <input type="text" placeholder="请输入注册资金" value="" name="reg_capital">
                                    </form>
                                    <input type="submit" value="保存" class="btn_small">
                                    <a id="cancelStages" class="btn_cancel_s" href="javascript:void(0)">取消</a>
                                </div>

                                <div class="clear"></div>

                                <div class="dn" id="cloneInvest">
                                    <input type="hidden" class="select_invest_hidden" name="select_invest_hidden">
                                </div>
                            </form>
                        </dd>
                    </dl>
                    <!-- end .c_stages -->


                    <div id="Member">
                        <!--有创始团队-->
                        <dl class="c_section c_member">
                            <dt>
		                        	<h2><em></em>公司法人</h2>
		                    		<a title="添加创始人" class="c_add" href="javascript:void(0)"></a>
	                    			</dt>
                            <dd>

                                <div class="member_wrap">

                                    <!-- 无创始人 -->
                                    <div class="member_info addnew_right dn">
                                        展示公司的领导班子，<br>提升诱人指数！<br>
                                        <a class="member_edit" href="javascript:void(0)">+添加成员</a>
                                    </div>

                                    <!-- 编辑创始人 -->
                                    <div class="member_info newMember dn">
                                        <form class="memberForm">
                                            <div class="new_portrait">
                                                <input type="hidden" value="7" name="type" class="type">
                                                <input type="hidden" value="images/leader_default.png" name="photo" class="leaderInfos">
                                            </div>
                                            <input type="text" placeholder="请输入法人姓名" value="" name="legal_person">
                                            <div class="clear"></div>
                                            <input type="submit" value="保存" class="btn_small">
                                            <a class="btn_cancel_s member_delete" href="javascript:void(0)">删除</a>
                                            <input type="hidden" value="11493" class="leader_id">
                                        </form>
                                    </div>

                                    <!-- 显示创始人 -->
                                    <div class="member_info" style="height: 20px;">
                                        <a title="编辑创始人" class="c_edit member_edit" href="javascript:void(0)"></a>
                                        <div style="font-size: 25px;margin-left: 75px;">
                                            <?php echo htmlentities($company['legal_person']); ?>
                                            <a target="_blank" class="weibo" href="http://weimob.weibo.com"></a>
                                        </div>
                                    </div>

                                </div>
                                <!-- end .member_wrap -->
                            </dd>
                        </dl>
                    </div>
                    <!-- end #Member -->


                    <!--公司深度报道-->
                    <div id="Reported">
                        <!--无报道-->
                        <dl class="c_section c_reported">
                            <dt>
		                	<h2><em></em>公司深度报道</h2>
                   			<a title="添加报道" class="c_add" href="javascript:void(0)"></a>
		                </dt>
                            <dd>
                                <!-- 编辑报道 -->
                                <ul class="reset">
                                    <li>
                                        <a style="" class="article" title="https://news.sina.com.cn/" target="_blank" href="http://www.baidu.com">https://news.sina.com.cn/</a>
                                        <a title="编辑报道" class="c_edit dn" href="javascript:;" style="display: inline;"></a>
                                        <form class="reportForm dn">
                                            <input type="text" placeholder="请输入文章标题" value="" name="articleTitle" class="valid">
                                            <input type="text" placeholder="请输入文章链接" value="" name="articleUrl" class="valid"><span for="articleUrl" generated="true" class="error" style="display: none;">请输入有效的文章链接</span>
                                            <input type="submit" value="保存" class="btn_small">
                                            <a class="btn_cancel_s report_delete" href="javascript:;">删除</a>
                                            <input type="hidden" value="5235" class="article_id">
                                        </form>
                                    </li>
                                    <li>
                                        <a style="" class="article" title="https://news.sina.com.cn/" target="_blank" href="http://www.baidu.com">https://news.sina.com.cn/</a>
                                        <a title="编辑报道" class="c_edit dn" href="javascript:;" style="display: inline;"></a>
                                        <form class="reportForm dn">
                                            <input type="text" placeholder="请输入文章标题" value="" name="articleTitle" class="valid">
                                            <input type="text" placeholder="请输入文章链接" value="" name="articleUrl" class="valid">
                                            <input type="submit" value="保存" class="btn_small">
                                            <a class="btn_cancel_s report_delete" href="javascript:;">删除</a>
                                            <input type="hidden" value="5236" class="article_id">
                                        </form>
                                    </li>
                                </ul>

                                <!-- 无报道 -->
                                <div class="addnew_right reported_info dn">
                                    展示外界对公司的深度报道，<br>便于求职者了解公司！<br>
                                    <a class="report_edit" href="javascript:void(0)">+添加报道</a>
                                </div>

                                <ul class="newReport dn">
                                    <li>
                                        <a style="display:none;" class="article" title="" target="_blank"></a>
                                        <a title="编辑报道" class="c_edit dn" href="javascript:;"></a>
                                        <form class="reportForm">
                                            <input type="text" placeholder="请输入文章标题" value="" name="articleTitle">
                                            <input type="text" placeholder="请输入文章链接" value="" name="articleUrl">
                                            <input type="submit" value="保存" class="btn_small">
                                            <a class="btn_cancel_s report_cancel" href="javascript:;">取消</a>
                                            <input type="hidden" value="" class="article_id">
                                        </form>
                                    </li>
                                </ul>
                            </dd>
                        </dl>
                        <!-- end .c_reported -->
                    </div>
                    <!-- end #Reported -->

                </div>
            </div>

            <!-------------------------------------弹窗lightbox  ----------------------------------------->
            <div style="display:none;">
                <div style="width:650px;height:470px;" class="popup" id="logoUploader">
                    <object width="650" height="470" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" id="FlashID">
		  <param value="../../flash/avatar.swf?url=http://www.lagou.com/cd/saveProfileLogo.json" name="movie">
		  <param value="high" name="quality">
		  <param value="opaque" name="wmode">
		  <param value="111.0.0.0" name="swfversion">
		  <!-- 此 param 标签提示使用 Flash Player 6.0 r65 和更高版本的用户下载最新版本的 Flash Player。如果您不想让用户看到该提示，请将其删除。 -->
		  <param value="../../Scripts/expressInstall.swf" name="expressinstall">
		  <!-- 下一个对象标签用于非 IE 浏览器。所以使用 IECC 将其从 IE 隐藏。 -->
		  <!--[if !IE]>-->
		  <object width="650" height="470" data="../../flash/avatar.swf?url=http://www.lagou.com/cd/saveProfileLogo.json" type="application/x-shockwave-flash">
		    <!--<![endif]-->
		    <param value="high" name="quality">
		    <param value="opaque" name="wmode">
		    <param value="111.0.0.0" name="swfversion">
		    <param value="../../Scripts/expressInstall.swf" name="expressinstall">
		    <!-- 浏览器将以下替代内容显示给使用 Flash Player 6.0 和更低版本的用户。 -->
		    <div>
		      <h4>此页面上的内容需要较新版本的 Adobe Flash Player。</h4>
		      <p><a href="http://www.adobe.com/go/getflashplayer"><img width="112" height="33" src="/static/images/get_flash_player.gif" alt="获取 Adobe Flash Player"></a></p>
		    </div>
		    <!--[if !IE]>-->
		  </object>
                    <!--<![endif]-->
                    </object>
                </div>
                <!-- #logoUploader -->
            </div>
            <!------------------------------------- end ----------------------------------------->

            <script src="/static/js/company.min.js" type="text/javascript"></script>
            <script>
                var avatar = {};
                avatar.uploadComplate = function(data) {
                    var result = eval('(' + data + ')');
                    if (result.success) {
                        jQuery('#logoShow img').attr("src", ctx + '/' + result.content);
                        jQuery.colorbox.close();
                    }
                };
            </script>
            <div class="clear"></div>
            <input type="hidden" value="d1035b6caa514d869727cff29a1c2e0c" id="resubmitToken">
            <a rel="nofollow" title="回到顶部" id="backtop" style="display: inline;"></a>
        </div>
        <!-- end #container -->
    </div>
    <!-- end #body -->
    <div id="footer">
        <div class="wrapper">
            <a rel="nofollow" target="_blank" href="about.html">联系我们</a>
            <a target="_blank" href="http://www.lagou.com/af/zhaopin.html">互联网公司导航</a>
            <a rel="nofollow" target="_blank" href="http://e.weibo.com/lagou720">拉勾微博</a>
            <a rel="nofollow" href="javascript:void(0)" class="footer_qr">拉勾微信<i></i></a>
            <div class="copyright">&copy;2013-2014 Lagou <a href="http://www.miitbeian.gov.cn/state/outPortal/loginPortal.action" target="_blank">京ICP备14023790号-2</a></div>
        </div>
    </div>

    <script src="/static/js/core.min.js" type="text/javascript"></script>
    <script src="/static/js/popup.min.js" type="text/javascript"></script>

    <!--  -->


    <div id="cboxOverlay" style="display: none;"></div>
    <div id="colorbox" class="" role="dialog" tabindex="-1" style="display: none;">
        <div id="cboxWrapper">
            <div>
                <div id="cboxTopLeft" style="float: left;"></div>
                <div id="cboxTopCenter" style="float: left;"></div>
                <div id="cboxTopRight" style="float: left;"></div>
            </div>
            <div style="clear: left;">
                <div id="cboxMiddleLeft" style="float: left;"></div>
                <div id="cboxContent" style="float: left;">
                    <div id="cboxTitle" style="float: left;"></div>
                    <div id="cboxCurrent" style="float: left;"></div><button type="button" id="cboxPrevious"></button><button type="button" id="cboxNext"></button><button id="cboxSlideshow"></button>
                    <div id="cboxLoadingOverlay" style="float: left;"></div>
                    <div id="cboxLoadingGraphic" style="float: left;"></div>
                </div>
                <div id="cboxMiddleRight" style="float: left;"></div>
            </div>
            <div style="clear: left;">
                <div id="cboxBottomLeft" style="float: left;"></div>
                <div id="cboxBottomCenter" style="float: left;"></div>
                <div id="cboxBottomRight" style="float: left;"></div>
            </div>
        </div>
        <div style="position: absolute; width: 9999px; visibility: hidden; display: none;"></div>
    </div>
</body>

</html>