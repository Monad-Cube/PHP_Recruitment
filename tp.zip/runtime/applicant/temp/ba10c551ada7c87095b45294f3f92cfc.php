<?php /*a:1:{s:63:"D:\WampServer\www\ThinkPHP\tp\app\applicant\view\Test\test.html";i:1591685961;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>文章添加</title>
    <script src="https://apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script>
</head>

<body>
    <h3>文章添加</h3>
    <form action="Test" method="post" enctype="multipart/form-data">
        文章标题：<input type="text" name="title" value=""><br /><br /> 文章描述：
        <input type="text" name="description" value=""><br /><br /> 文章封面：
        <input type="file" name="file" /> <br><br>
        <button type="submit">提交</button><br><br>
    </form>

    <img src="" class="img" width="300">

    <script type="text/javascript">
        $("input[name='image_url']").change(function() {
            $(".img").attr("src", URL.createObjectURL($(this)[0].files[0]));
        });
    </script>
</body>

</html>