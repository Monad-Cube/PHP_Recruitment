<?php /*a:1:{s:61:"D:\WampServer\www\ThinkPHP\tp\view\applicant\index\index.html";i:1590335222;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div>
        姓名：<?php echo htmlentities($name); ?>

        <br>
    
        邮箱：<?php echo htmlentities($email); ?>    
    </div>
</body>
</html>