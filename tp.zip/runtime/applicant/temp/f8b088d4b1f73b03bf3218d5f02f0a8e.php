<?php /*a:1:{s:64:"D:\WampServer\www\ThinkPHP\tp\app\applicant\view\data\index.html";i:1591420298;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div>
        姓名：<?php echo htmlentities($name); ?>

        <br>
    
        邮箱：<?php echo htmlentities($email); ?>    
    </div>
    <a href="/Redirect/test" >hellow</a>
</body>
</html>