-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- 主机： 127.0.0.1:3306
-- 生成日期： 2020-06-20 03:37:26
-- 服务器版本： 10.4.10-MariaDB
-- PHP 版本： 7.4.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `recruit`
--

-- --------------------------------------------------------

--
-- 表的结构 `applicant`
--

DROP TABLE IF EXISTS `applicant`;
CREATE TABLE IF NOT EXISTS `applicant` (
  `id` int(3) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `job_type` varchar(20) NOT NULL,
  `age` int(3) NOT NULL,
  `address` varchar(50) NOT NULL,
  `education` varchar(50) NOT NULL,
  `resume` varchar(50) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `collection_position_id` varchar(5) NOT NULL,
  `collection_company_id` int(11) NOT NULL,
  `state` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_2` (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `applicant`
--

INSERT INTO `applicant` (`id`, `name`, `email`, `job_type`, `age`, `address`, `education`, `resume`, `contact`, `collection_position_id`, `collection_company_id`, `state`) VALUES
(1, '李立', '2315971342@qq.com', '前端开发', 25, '杭州', '杭州电子科技大学', '大学期间参加互联网大赛获一等奖，参与制作校园app。', '19722225555', '0', 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `company`
--

DROP TABLE IF EXISTS `company`;
CREATE TABLE IF NOT EXISTS `company` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `email` varchar(20) NOT NULL,
  `trade` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `address` varchar(20) NOT NULL,
  `legal_person` varchar(20) NOT NULL,
  `reg_capital` varchar(20) NOT NULL,
  `info` varchar(50) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `state` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `company`
--

INSERT INTO `company` (`id`, `email`, `trade`, `name`, `address`, `legal_person`, `reg_capital`, `info`, `contact`, `state`) VALUES
(1, '123@qq.com', '自媒体', '澎湃工作室', '北京', '李萍', '2,000,000', '我们是一家以自媒体为中心的互联网中型公司，我们的在杭州有三家工作室，各大媒体平台月活跃超千万。', '0567 7777', 1),
(2, '666@qq.com', '金融', '金融天地', '杭州', '王今江', '100,100,000', '我们公司的主要业务是帮助投资理财，公司规模较大，拥有1000名员工，并在2018年于纽约上市。', '9934-8879', 1);

-- --------------------------------------------------------

--
-- 表的结构 `position`
--

DROP TABLE IF EXISTS `position`;
CREATE TABLE IF NOT EXISTS `position` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `company` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  `place` varchar(10) NOT NULL,
  `number` int(5) NOT NULL,
  `post_time` varchar(20) NOT NULL,
  `requirement` varchar(50) NOT NULL,
  `treatment` varchar(50) NOT NULL,
  `allowance` varchar(20) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `popularity` int(6) NOT NULL,
  `state` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `position`
--

INSERT INTO `position` (`id`, `company`, `name`, `type`, `place`, `number`, `post_time`, `requirement`, `treatment`, `allowance`, `contact`, `popularity`, `state`) VALUES
(1, '澎湃工作室', 'vue', '前端开发', '杭州', 10, '2020.06.01', '本科学历以上，学习前端知识至少3年，熟练掌握vue。', '7k-9k', '有年终奖', '13822225555', 1, 1),
(2, '澎湃工作室', 'php', '后端开发', '杭州', 10, '2020.05.01', '本科学历以上，学习后端知识至少5年，掌握php，熟练使用tp框架。', '12k-16k', '有年终奖', '13822225555', 64, 1);

-- --------------------------------------------------------

--
-- 表的结构 `resume`
--

DROP TABLE IF EXISTS `resume`;
CREATE TABLE IF NOT EXISTS `resume` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `position_id` int(5) NOT NULL,
  `applicant_id` int(5) NOT NULL,
  `state` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `resume`
--

INSERT INTO `resume` (`id`, `position_id`, `applicant_id`, `state`) VALUES
(16, 2, 1, 2);

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `email` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `property` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`email`, `password`, `property`) VALUES
('2315971342@qq.com', '123456', 'appicant'),
('123@qq.com', '123456', 'company'),
('333@qq.com', '123456', 'applicant'),
('3333333@qq.com', '123456', 'applicant'),
('666@qq.com', '123456', 'company'),
('123456@qq.com', '123456', 'company'),
('123456@qq.com', '123456', 'company'),
('123456@qq.com', '123456', 'applicant'),
('2315971342@qq.com', '123456', 'applicant'),
('2315971342@qq.com', '123456', 'applicant');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
